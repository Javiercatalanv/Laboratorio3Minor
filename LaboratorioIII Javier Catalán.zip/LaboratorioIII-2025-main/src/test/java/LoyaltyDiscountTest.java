import cl.ucn.modelo.*;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.junit.Before;
import org.junit.Test;
import jakarta.persistence.EntityManager;
import java.time.LocalDate;
import static org.junit.Assert.*;

public class LoyaltyDiscountTest {

    private EntityManager em;
    private EntityManagerFactory emf;
    private LoyaltyDiscountEngine engine;
    private Customer customer;

    @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("shopping");
        em = emf.createEntityManager();
        engine = new LoyaltyDiscountEngine(em);
    }

    @Test
    public void testDescuentoNulo() {
        Customer cliente = new Customer("1",  LocalDate.now(), 0, Customer.LoyaltyLevel.BASIC,false);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.0, descuento, 0.001);
    }

    @Test
    public void testClienteSilver() {
        Customer cliente = new Customer("2",LocalDate.now().minusYears(3), 50,  Customer.LoyaltyLevel.SILVER, false);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.05, descuento, 0.001);
    }

    @Test
    public void testAntiguedadMayorCinco() {
        Customer cliente = new Customer("3", LocalDate.now().minusYears(6), 10, Customer.LoyaltyLevel.GOLD, false);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.15, descuento, 0.001);
    }

    @Test
    public void testMasDeCienOrdenes() {
        Customer cliente = new Customer("4", LocalDate.now().minusYears(3), 101, Customer.LoyaltyLevel.GOLD, false);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.15, descuento, 0.001);
    }

    @Test
    public void testPromocionActiva() {
        Customer cliente = new Customer("5", LocalDate.now().minusYears(1), 0, Customer.LoyaltyLevel.BASIC, true);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.10, descuento, 0.001);
    }

    @Test
    public void testDescuentoMaximo() {
        Customer cliente = new Customer("6",  LocalDate.now().minusYears(10), 150, Customer.LoyaltyLevel.PLATINUM, true);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.30, descuento, 0.001);
    }

    @Test
    public void testGoldConPromoYAntiguedad() {
        Customer cliente = new Customer("11", LocalDate.now().minusYears(6), 20, Customer.LoyaltyLevel.GOLD, true);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.25, descuento, 0.001);
    }

    @Test
    public void testPlatinumSoloNivel() {
        Customer cliente = new Customer("12", LocalDate.now(), 0, Customer.LoyaltyLevel.PLATINUM, false);
        double descuento = engine.computeDiscount(cliente);
        assertEquals(0.15, descuento, 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testExcepcionClienteNull() {
        engine.computeDiscount(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testExcepcionClienteSinId() {
        Customer cliente = new Customer(null, LocalDate.now(), 10, Customer.LoyaltyLevel.GOLD, false);
        engine.computeDiscount(cliente);
    }
}
